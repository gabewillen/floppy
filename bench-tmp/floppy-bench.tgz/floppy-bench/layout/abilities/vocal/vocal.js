// The ECMAScript of abilities/vocal/vocal.scx (SCXML 5.8): loaded by its root
// <script src="vocal.js">, so every function here is a global of the
// document's data model, callable from its cond and expr attributes.

// applying

// Where the speech service writes the audio: output_prefix + operation +
// "." + the media subtype.
function outputPath() {
  return output_prefix + operation + '.' + media_type.split('/')[1];
}

// The speech service call in hand, by its generated invoke id.
function speechTarget() {
  return '#_' + speech;
}

// An event of the speech service call in hand, not of a cancelled one.
function isCurrent(_event) {
  return _event.invokeid === speech;
}

// The reply in hand is drafted (D262): it has no parts, and the speech
// service reads it from the events sent on to it.
function isDrafted() {
  return parts === null;
}

// A chunk of the streamed encoding (D203), when it has an audio reference
// and a sequence number (D41: its events are unchecked).
function isChunk(_event) {
  var data = Object(_event.data);
  return typeof data.audio === 'string' && typeof data.sequence === 'number';
}

// The speech service's encoding output, when it has an audio reference;
// else the answer kept so far (D41: its events are unchecked).
function encodedAnswer(_event) {
  return typeof Object(_event.data).audio === 'string' ? _event.data : encoded;
}

// The speech service's failure message, when it has one; else the failure
// kept so far.
function failureAnswer(_event) {
  return typeof Object(_event.data).message === 'string' ? _event.data.message : failure;
}

// The service ended with an encoding.
function hasEncoded() {
  return encoded !== null;
}

function failureMessage() {
  return failure === null ? 'The speech service ended without encoding.' : failure;
}

function speechRunFailure(_event) {
  return 'The speech service could not run (' + _event.name + ').';
}
