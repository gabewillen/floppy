// The ECMAScript of abilities/reflection/reflection.scx (SCXML 5.8): loaded by its root
// <script src="reflection.js">, so every function here is a global of the
// document's data model, callable from its cond and expr attributes.

// idle

// An input deferred while the previous reflection was in hand.
function hasDeferredInput() {
  return deferred.length > 0;
}

// How the turn ended (decision D139): completed unless the input says.
function inputOutcome(input) {
  return typeof input.outcome === 'string' ? input.outcome : 'completed';
}

function inputFailure(input) {
  return typeof input.failure === 'string' ? input.failure : null;
}

// What the bot knows of itself (decision D145), null when not told.
// The turn's choices (decision D221), none when the input has none.
function inputChoices(input) {
  return Array.isArray(input.choices) ? input.choices : [];
}

// The learned behaviors that declined the turn (decision D230).
function inputDeclined(input) {
  return Array.isArray(input.declined) ? input.declined : [];
}

function inputSelf(input) {
  return input.self === undefined ? null : input.self;
}

// recalling

function hasNoMemory() {
  return memory === null;
}

// The episodes' select: the turn's focus or none.
function episodeSelectStatements() {
  return [{sql: select_episodes, parameters: [cognition_input.focus, cognition_input.focus]}];
}

// The inventory's select appended: every behavior.
function behaviorSelectStatements() {
  return statements.concat([{sql: select_behaviors, parameters: [null, null]}, {sql: select_triggers, parameters: [null, null]}]);
}

function recalledEpisodes(_event) {
  return _event.data.results[0].rows.map(function (r) { return JSON.parse(r.values[0]); });
}

// Whether the recalled inventory holds a behavior a change or a break may name.
function hasBehaviors() {
  return behaviors.length > 0;
}

// Whether the inventory holds a behavior a change may name: not one that
// declined this turn, which rightly did not answer it (decision D230).
function hasChangeable() {
  return behaviors.some(function (b) { return declined.indexOf(b.name) < 0; });
}

function recalledLog() {
  return 'turn ' + turn + ': ' + prior_episodes.length + ' episodes, ' + behaviors.length + ' behaviors';
}

// A failed or cancelled turn, which reflection only remembers (decision D139).
function isUnreflected() {
  return outcome !== 'completed';
}

// A turn that taught the learning a lesson, which learns it itself
// (decision D149).
function isTaught() {
  return cognition_output.some(function (s) { return s.event === 'bot.ability.learning.input'; });
}

// A turn the bot's own abilities caused (a routine's tick, a lesson's
// result), with no one's input to learn from (decision D151).
function isOwnStimulus() {
  var event = Object(cognition_input.stimulus).event;
  return event === 'bot.behavior.tick' || event === 'bot.ability.learning.output';
}

function isOnlyRemembered() {
  return isUnreflected() || isTaught() || isOwnStimulus();
}

// Why a turn isOnlyRemembered(): its outcome, a lesson taught, or its own
// stimulus's event.
function unreflectedLog() {
  if (isUnreflected()) {
    return 'turn ' + turn + ': ' + outcome;
  }
  if (isTaught()) {
    return 'turn ' + turn + ': taught';
  }
  return 'turn ' + turn + ': ' + Object(cognition_input.stimulus).event;
}

function recallFailedMessage(detail) {
  return 'Reflection memory recall failed: ' + detail;
}

// processing

function selectTimeoutDelay() {
  return select_timeout_ms + 'ms';
}

function selectCeilingDelay() {
  return select_ceiling_ms + 'ms';
}

// The select input (as model-facing XML, decision D201), with the repair
// feedback (selection_feedback, decision D130) last when this attempt
// repairs a rejection.
function selectPrompt() {
  return select_input + selectFeedback();
}

function selectInput() {
  var input = {cognition_input: cognition_input, cognition_output: cognition_output, prior_episodes: prior_episodes, behaviors: behaviors};
  if (hasPersona()) {
    input.self = self;
  }
  return input;
}

// A persona to revise: the bot was told its owner's traits (decision D145).
function hasPersona() {
  return self !== null && Array.isArray(self.traits) && self.traits.length > 0;
}

// The selections of this hop's reply, every dispatch call's.
function replySelections(_event) {
  var calls = Array.isArray(_event.data.tool_calls) ? _event.data.tool_calls : [];
  return calls.reduce(function (all, call) { return all.concat(Array.isArray(Object(call.args).events) ? call.args.events : []); }, []);
}

function isRevision(s) {
  return s.event === 'bot.ability.persona.revise';
}

// This hop's answer with more than one inventory event or more than one
// revision (decision D145).
function isOverSelection(_event) {
  if (!isGenerate(_event)) {
    return false;
  }
  var selections = replySelections(_event);
  var revisions = selections.filter(isRevision).length;
  return revisions > 1 || selections.length - revisions > 1;
}

// Whether the reply changes a behavior that declined this turn (decision D230).
function isDeclinedChange(_event) {
  if (!isGenerate(_event)) {
    return false;
  }
  return replySelections(_event).some(function (s) {
    return s.event === 'bot.behavior.change' && s.data !== undefined && s.data !== null && declined.indexOf(s.data.name) >= 0;
  });
}

function declinedChangeRejection() {
  return ({key: 'declined-change', message: 'bot.behavior.change may not name ' + declined.join(', ') + ': it rightly declined this turn'});
}

function overSelectionRejection() {
  return ({key: 'over-selection', message: 'select at most one of bot.behavior.create, bot.behavior.change or bot.behavior.break, and at most one bot.ability.persona.revise'});
}

// A call's selections with a revision first (none when it holds no list,
// as replySelections reads it).
function revisionsFirst(events) {
  if (!Array.isArray(events)) {
    return [];
  }
  return events.filter(isRevision).concat(events.filter(function (s) { return !isRevision(s); }));
}

function selectFeedback() {
  return select_rejection === null ? '' : '\n' + selection_feedback.replace('MESSAGE', function () { return rejectionMessage(select_rejection); });
}

// The code of a generate.failed, else gen_failure unchanged.
function generateFailure(_event) {
  return typeof Object(_event.data).code === 'string' ? _event.data.code : gen_failure;
}

// An event of this hop's call. processing is entered once per select
// attempt (a repair enters it again), and each entry invokes the service
// under a fresh gen_id, so a late event of an earlier entry's cancelled
// call does not match: scxml.rs keeps the events a cancelled invocation
// queued before its cancel.
function isGenerate(_event) {
  return _event.invokeid === gen_id;
}

function hasSelection(_event) {
  return isGenerate(_event) && Array.isArray(selected);
}

// The rejection of this hop's call (generate.failed, decision D126): present
// exactly for not-json and schema-mismatch, the calls the model can repair.
function selectRejection(_event) {
  return _event.data.rejection === undefined ? null : _event.data.rejection;
}

function isSelectRejection(_event) {
  return isGenerate(_event) && gen_rejection !== null;
}

// The failure message for a rejected selection (decision D130).
function rejectionMessage(r) {
  return 'Selection rejected: ' + r.message;
}

function selectRejectedMessage() {
  return rejectionMessage(gen_rejection);
}

function rejectedLog() {
  return 'attempt ' + select_attempt + ': ' + gen_rejection.key;
}

function selectFailedMessage(detail) {
  return 'Reflection select failed (' + detail + ')';
}

function generateFailedMessage() {
  return selectFailedMessage(gen_failure === null ? 'no selection' : gen_failure);
}

function isSelectHopTimeout(_event) {
  return _event.sendid === hop_timer || _event.sendid === ceiling_timer;
}

// The hop timeout's failure: the select child is cancelled on the hop
// timeout (synchronously, as leaving the invoking state cancels it).
function selectTimedOutMessage() {
  return 'Reflection child cancellation timed out.';
}

// routing_rejection

// The same-rejection check (decision D130): this hop's rejection is the one
// it repaired. The whole diagnostic is compared: a
// D126 key names only where the arguments first fail, so its message is
// compared too.
function isSameSelectRejection() {
  return select_rejection !== null && select_rejection.key === gen_rejection.key && select_rejection.message === gen_rejection.message;
}

// Another repair is allowed: at most max_selection_repairs (decision D130).
function canRepairSelect() {
  return select_attempt < max_selection_repairs;
}

// breaking

// A break: the trimmed reason, by name.
function breakBehaviorStatements() {
  return [{sql: break_behavior, parameters: [typeof behavior.reason === 'string' ? behavior.reason.trim() : '', behavior.name]}];
}

function hasBrokenBehavior(_event) {
  return _event.data.results[0].rowcount === 1;
}

function brokenLog() {
  return behavior.name + ' BROKEN (break)';
}

function unknownBreakMessage() {
  return breakFailedMessage('Reflection break selected unknown behavior: ' + behavior.name + '.');
}

function breakFailedMessage(detail) {
  return 'Reflection break failed: ' + detail;
}

// storing

// The turn's cognitive episode, with the behavior the turn applied (null: none).
function cognitiveEpisode(applied) {
  var input = cognition_input;
  var episode = {focus: input.focus, focus_candidates: input.focus_candidates, stimulus_name: input.stimulus.event, heard: heardWords(input.stimulus), output: cognition_output, behavior: applied};
  if (isUnreflected()) {
    episode.outcome = outcome;
    episode.failure = turn_failure;
  }
  var images = seenImages(input.stimulus);
  if (images.length > 0) {
    episode.images = images;
  }
  return episode;
}

// The images the stimulus carried, in order, each once, at most 8 (mosfet.py
// keeps a turn's worth, media.MAX_TURN_IMAGES, in EpisodeData.parts): each
// media object ({image, media_type}, the reference floppy passes media by)
// read through envelopes and arrays, kept as its reference and media type,
// so a recalled episode shows the model what the turn saw (decision D252).
function seenImages(stimulus) {
  var found = [];
  function read(item, depth) {
    if (depth > 8 || found.length >= 8 || item === null || typeof item !== 'object') {
      return;
    }
    if (Array.isArray(item)) {
      item.forEach(function (each) { read(each, depth + 1); });
      return;
    }
    if (typeof item.image === 'string' && (typeof item.media_type === 'string' || item.media_type === null)) {
      if (!found.some(function (each) { return each.image === item.image; })) {
        found.push({image: item.image, media_type: item.media_type});
      }
      return;
    }
    Object.keys(item).forEach(function (key) { read(item[key], depth + 1); });
  }
  read(stimulus, 0);
  return found;
}

// The words the stimulus carried, in order, each once (mosfet.py's
// EpisodeData.heard): the content of each message of a text type, as the
// payloads holding them declare them, read through envelopes and arrays,
// at most 2048 UTF-8 bytes in all (a short-term turn's bound), the last cut
// at a whole word.
function heardWords(stimulus) {
  var found = [];
  var room = 2048;
  function read(item, depth) {
    if (depth > 8 || room <= 0 || item === null || typeof item !== 'object') {
      return;
    }
    if (Array.isArray(item)) {
      item.forEach(function (each) { read(each, depth + 1); });
      return;
    }
    if (typeof item.content === 'string' && typeof item.content_type === 'string' && /^text\//i.test(item.content_type)) {
      var words = item.content.trim();
      if (words !== '' && found.indexOf(words) < 0) {
        words = cutAtWord(words, room);
        if (words !== '') {
          found.push(words);
          room -= utf8Bytes(words);
        }
      }
      return;
    }
    Object.keys(item).forEach(function (key) { read(item[key], depth + 1); });
  }
  read(stimulus, 0);
  return found;
}

// The words within bytes UTF-8 bytes: whole, or their longest prefix
// ending at a word break, trailing white space removed.
function cutAtWord(words, bytes) {
  if (utf8Bytes(words) <= bytes) {
    return words;
  }
  var end = 0;
  var used = 0;
  for (var i = 0; i < words.length; i++) {
    used += utf8Bytes(words.charAt(i));
    if (used > bytes) {
      break;
    }
    if (/\s/.test(words.charAt(i))) {
      end = i;
    }
  }
  return words.slice(0, end).trim();
}

function utf8Bytes(text) {
  var bytes = 0;
  for (var i = 0; i < text.length; i++) {
    var code = text.charCodeAt(i);
    bytes += code < 0x80 ? 1 : code < 0x800 ? 2 : (code >= 0xd800 && code < 0xdc00) ? 4 : (code >= 0xdc00 && code < 0xe000) ? 0 : 3;
  }
  return bytes;
}

// Whether a failing turn has not tried to store its episode yet.
function isEpisodeUnstored() {
  return episode === null;
}

// The episode's insert, and its vector's when it has one.
function insertEpisodeStatements() {
  var statements = [{sql: insert_episode, parameters: [cognition_input.focus, JSON.stringify(episode)]}];
  return vector === null ? statements : statements.concat([{sql: insert_embedding, parameters: [vector]}]);
}

// The episode's words (decision D256): what was heard, one message per
// line.
function episodeWords() {
  return episode.heard.join('\n');
}

function hasEpisodeWords() {
  return episodeWords() !== '';
}

function hasNoEpisodeWords() {
  return !hasEpisodeWords();
}

// The episode's words as one document to embed.
function episodeEmbeddingInput() {
  return ({id: embedding_requests.storing_embedding, role: 'document', items: [{parts: [{kind: 'text', text: episodeWords()}]}]});
}

// A unit vector's compact text, as a person's representative voice is
// kept (namespaces/conversation encode_voice): i8: and the standard
// base64 of each component times 127, rounded, as a signed byte.
function compactVector(values) {
  var alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  var bytes = values.map(function (value) { return (Math.max(-127, Math.min(127, Math.round(value * 127))) + 256) % 256; });
  var text = 'i8:';
  for (var i = 0; i < bytes.length; i += 3) {
    var a = bytes[i], b = i + 1 < bytes.length ? bytes[i + 1] : 0, c = i + 2 < bytes.length ? bytes[i + 2] : 0;
    text += alphabet.charAt(a >> 2) + alphabet.charAt(((a & 3) << 4) | (b >> 4));
    text += i + 1 < bytes.length ? alphabet.charAt(((b & 15) << 2) | (c >> 6)) : '=';
    text += i + 2 < bytes.length ? alphabet.charAt(c & 63) : '=';
  }
  return text;
}

function storedLog() {
  return 'turn ' + turn;
}

function episodeStoreFailedMessage(detail) {
  return 'Reflection episode store failed: ' + detail;
}

// revising

// A create whose name the recalled inventory does not hold.
function isCreate() {
  return create_intent !== null && !behaviors.some(function (b) { return b.name === intent.name; });
}

// The inventory event the intent came as.
function intentEvent() {
  return create_intent === null ? 'bot.behavior.change' : 'bot.behavior.create';
}

// Where the builder sends its progress (decision D101): this session, past
// the revision that invokes it.
function progressTarget() {
  return '#_scxml_' + _sessionid;
}

function revisionFailedMessage(detail) {
  return 'Reflection revision failed: ' + detail;
}

// The revision's inactivity bound and its backstop: the bot's (bounds),
// else this document's defaults (decision D101).
function revisingTimeoutDelay() {
  return (bounds.revising_timeout_ms === undefined ? revising_timeout_ms : bounds.revising_timeout_ms) + 'ms';
}

function revisingCeilingDelay() {
  return (bounds.revising_ceiling_ms === undefined ? revising_ceiling_ms : bounds.revising_ceiling_ms) + 'ms';
}

// The data a selection is sent with: its data object, else {} (no data,
// null, or a non-object).
function selectionData(s) {
  return s.data !== null && typeof s.data === 'object' && !Array.isArray(s.data) ? s.data : ({});
}

// memory

// Whether the event answers the request the state `name` last sent the
// memory (decision D266): its id is that request's.
function isMemoryReply(name) {
  return memory_requests[name] !== undefined && _event.data.id === memory_requests[name];
}

// A reply of the Embedding ability to the request the state name last sent.
function isEmbeddingReply(name) {
  return embedding_requests[name] !== undefined && _event.data.id === embedding_requests[name];
}
