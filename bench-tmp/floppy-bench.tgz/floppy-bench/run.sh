#!/bin/bash
# run.sh FLOPPY_CHECKOUT : replays a recorded 3-turn live floppy session on the logical clock
# (same recording the cloud VM numbers came from) and prints per-call engine timings.
# Needs: rust toolchain, WASI_SDK_PATH pointing at wasi-sdk 25, python3.
set -eu
F=$(cd "$1" && pwd); H=$(cd "$(dirname "$0")" && pwd); A=$F/target/bench
cd "$F"
git apply --check "$H/perf-instrument.patch" 2>/dev/null && git apply "$H/perf-instrument.patch" || echo "(instrument patch already applied?)"
[ -f "$A/package-cache/index/.done" ] || { sh scripts/build-components.sh --artifacts-dir "$A" | tail -2; touch "$A/package-cache/index/.done"; }
( cd scxml.rs && CARGO_TARGET_DIR="$F/target/bench-scx" SCXML_WASM_ARTIFACTS_DIR="$A/scxml" cargo build --release -p scxml-cli 2>&1 | tail -1 )
SCX=$F/target/bench-scx/release/scx
W=$H/work; rm -rf "$W"; mkdir -p "$W/memory"; cp -R "$H/layout" "$W/layout"; cp -R "$H/media" "$W/media"
python3 - "$H/rec.log" "$W/rec.log" "$A" <<'PY'
import sys,json,glob,hashlib
src,dst,A=sys.argv[1:]
t={}
for f in glob.glob(A+'/package-cache/index/*.json'):
    d=json.load(open(f)); t[d.get('namespace-uri') or d.get('service-uri')]=d.get('component-sha256')
for l in open(A+'/scxml/manifest.tsv'):
    p=l.rstrip('\n').split('\t')
    if len(p)>=5 and p[1]=='scx': t['https://github.com/stateforward/scxml.rs/namespaces/scx']=p[4]
lines=open(src).read().split('\n'); h=json.loads(lines[0])
h['components_manifest_sha256']=hashlib.sha256(open(A+'/scxml/manifest.tsv','rb').read()).hexdigest()
for key,f in (('namespaces','extension_component_sha256'),('services','service_component_sha256')):
    for n in h[key]:
        if n['uri'] in t: n[f]=t[n['uri']]
        else: print('no local component for',n['uri'])
lines[0]=json.dumps(h,separators=(',',':')); open(dst,'w').write('\n'.join(lines))
PY
G=https://github.com/stateforward/floppy/services
for i in 1 2 3; do
  rm -rf "$W/memory" && mkdir -p "$W/memory"; rm -f "$W/spans.jsonl"
  start=$(python3 -c 'import time;print(time.time())')
  PERF_SPANS="$W/spans.jsonl" "$SCX" run --wasi $G/pgsql=inherit-network --env-file "$H/routed.env" \
    --dir "$G/sql=$W/memory::/memory" --dir "$G/speech=$W/media::/media" --dir "$G/generate=$W/media::/media" \
    --dir "$G/vision=$W/media::/media" --dir "$G/files=$W/layout/behaviors::/behaviors" \
    "$W/layout/environments/environment/environment.scx" --cache-dir "$A/package-cache" --offline \
    --replay "$W/rec.log" > "$W/out.jsonl" 2> "$W/err.txt" || true
  echo "run $i: wall $(python3 -c "import time;print(round(time.time()-$start,1))") s; $(tail -1 "$W/err.txt" | cut -c1-200)"
  python3 "$H/summary.py" "$W/spans.jsonl"
done
echo "Cloud VM (4 vCPU) reference, same recording and code: wall 22-26 s, open=14.5-17 s, http-response total=2.45-2.9 s, hand-off calls (2nd-4th biggest) ~320-440 ms"
echo "Undo the instrument patch afterwards: git -C $F checkout -- scxml.rs tests/tests/support/mod.rs Cargo.lock"
