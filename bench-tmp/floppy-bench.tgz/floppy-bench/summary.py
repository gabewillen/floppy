import json,sys,collections
S=[json.loads(l) for l in open(sys.argv[1])]
top=[s for s in S if s['scope']=='scxml' and s['name'].startswith('scxml.host-wasmtime.session-') and s['parent']=='0000000000000000']
d=collections.Counter(); c=collections.Counter()
for s in top: d[s['name'][27:]]+=(s['end']-s['start'])/1e6; c[s['name'][27:]]+=1
print(' '.join(f"{k}={v:.0f}ms/{c[k]}" for k,v in d.most_common(8)))
big=sorted([s for s in top if s['name'].endswith('http-response')],key=lambda s:-(s['end']-s['start']))[:4]
print('biggest http-response calls:',' '.join(f"{(s['end']-s['start'])/1e6:.0f}" for s in sorted(big,key=lambda s:s['start'])))
